#version 330

#ifndef IS_SEE_THROUGH
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:brmenu_look.glsl>

in vec3 Position;
in vec4 Color;
#ifndef IS_SEE_THROUGH
in ivec2 UV2;
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;

void main() {
    // brmenu: main-menu hover highlight, drawn while the free-look cursor is inside its button (brmenu_look.glsl)
    vec3 brmPos = Position;
#ifndef IS_SEE_THROUGH
    vec4 brmHl = brm_highlight(brmPos, Color, ModelViewMat, UV2);
#else
    vec4 brmHl = brm_highlight(brmPos, Color, ModelViewMat, ivec2(0, 0));
#endif
    gl_Position = brm_position(brmPos, ModelViewMat, 0);   // brmenu: free-look menu view

#ifndef IS_SEE_THROUGH
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    if (brmHl.a >= 0.0) vertexColor = brmHl;
}
