// BackroomsMenu: main menu "free look" view (server side: dev.brmenu.ui.MenuCamera.FreeLook, MenuScene).
//
// In the free-look menu the player rides a seat near the menu eye and turns their head freely; the menu itself must
// not turn. Every world vertex near the menu is therefore drawn from a FIXED view: the menu eye BRM_EYE looking north
// (-Z, so the reference view rotation is the identity) through a FIXED lens (vertical FOV 70, fitted inside the real
// window), whatever the player's own FOV, window shape or head rotation is. The cursor is the only thing that follows
// the head: its sprite (an item display marked by its brightness, see brm_mark) is placed every frame from the view
// rotation in ModelViewMat, so it moves at the full frame rate with no server round trip. The server hit-tests with
// the same mapping (BRM_K units per degree, clamped to the view) from the rotation the client reports. Below 100 %
// sensitivity the cursor also carries an offset, read from where the camera stands (brm_offset).
//
// Needs (from the including shader): ProjMat (projection.glsl), CameraBlockPos / CameraOffset (globals.glsl).
#ifndef BRMENU_LOOK_GLSL
#define BRMENU_LOOK_GLSL

const vec3 BRM_EYE = vec3(0.5, 101.6, 2000.5);   // world.MenuStage#camera
const ivec3 BRM_EYE_BLOCK = ivec3(0, 101, 2000);   // its block: the offset is read relative to it (exact, brm_offset)
const float BRM_D = 4.0;                           // MenuScene.DISTANCE (plane units)
const float BRM_TAN = 0.7002075382;                // tan(35 deg): the menu lens is FOV 70
const float BRM_HALF_V = BRM_D * BRM_TAN;          // MenuScene.VIEW_V
const float BRM_HALF_U = BRM_HALF_V * 16.0 / 9.0;  // MenuScene.VIEW_U
// plane units per degree of head turn at 100 % sensitivity (MenuCamera.FreeLook.K): the owner's tuned speed (16:9
// side edge at a 37.6 degree turn), one mapping for every window shape (the server cannot see the window), times the
// player's factor (brm_sens). The cursor also stops where the head may stop: BRM_MAX_TURN sideways, BRM_MAX_PITCH up
// / down (the server turns the head back there), so the client's real, head-turned frustum never culls the menu
// figure (living entities are frustum-culled; display entities are not)
const float BRM_K = BRM_HALF_V * 7.0 / 148.0;
const float BRM_MAX_TURN = 38.0;
const float BRM_MAX_PITCH = 30.0;
// how far the head part of the cursor follows the head (MenuCamera.FreeLook.HEAD_TURN / HEAD_PITCH): all the way
// round. Below 100 % a fast flick may outrun the server's re-centre; the cursor keeps following instead of waiting at
// BRM_MAX_TURN and then catching up in one jump. At 100 % the window edge (brm_screen) comes first.
const float BRM_HEAD_TURN = 180.0;
const float BRM_HEAD_PITCH = 90.0;
// the free-look camera stands BRM_BEHIND south of the eye (MenuCamera.FreeLook.BEHIND), moved east / south by the
// cursor offset / BRM_ENC (MenuCamera.FreeLook.ENC, brm_offset)
const float BRM_BEHIND = 1.5;
const float BRM_ENC = 100.0;

// the free-look camera stands 1.5 blocks behind the eye (MenuCamera.FreeLook); the locked camera exactly on it and
// the seated fallback 0.6 below it are left alone
bool brm_active() {
    if (ProjMat[3][3] > 0.5) return false;   // orthographic: GUI / HUD
    float d = distance(vec3(CameraBlockPos) - CameraOffset, BRM_EYE);
    return d > 1.2 && d < 2.5;
}

// sensitivity code of a light, -1 for none (see brm_sens)
int brm_code(ivec2 light) {
    if ((light.x & 15) != 0 || (light.y & 15) != 0) return -1;
    int b = light.x >> 4, s = light.y >> 4;
    if (b < 12 || b > 15 || s < 3 || s > 14) return -1;
    return (15 - b) * 12 + (s - 3);
}

// item display brightness (block 15, sky 1) or any sensitivity code (brm_code) = the shader-drawn cursor; (block 15,
// sky 2) = the server-placed cursor (shown only where this shader is not running)
int brm_mark(ivec2 light) {
    if (light.x == 240 && light.y == 16) return 1;
    if (light.x == 240 && light.y == 32) return 2;
    if (brm_code(light) >= 0) return 1;
    return 0;
}

// the player's cursor sensitivity (Settings "Cursor sensitivity" 0..100 %, MenuCamera.FreeLook#code), per player:
// the light of the shader cursor and of every hover highlight carries a code c = 0..47: block light 15 - c / 12, sky
// light 3 + c % 12. The factor is 10^((c - 40) / 40): 100 % = c 40 = x1 (+ the screen shape's raise), 0 % = c 0 =
// x0.1. Light is per entity and free of colour bits (no text-marker clash); nothing else in the menu is lit with
// block 12..15 and sky 3..14 (menu light is (n, 0) or (15, 15); the figure stands in sky light 15).
float brm_sens(ivec2 light) {
    int c = brm_code(light);
    return pow(10.0, float((c < 0 ? 40 : c) - 40) / 40.0);
}

// the visible window on the menu plane (half width, half height): the lens below is FOV 70 vertically, narrowed so a
// 16:9 view still fits a taller window; the cursor is clamped to it, so its tip reaches every edge and corner of the
// real screen and never leaves it (owner: "the cursor can go anywhere on the screen"; MenuCamera.FreeLook.screen)
vec2 brm_screen() {
    float aspect = abs(ProjMat[1][1] / ProjMat[0][0]);
    return BRM_HALF_V * vec2(max(aspect, 16.0 / 9.0), max(1.0, (16.0 / 9.0) / aspect));
}

// the cursor offset (plane units) the server carries below 100 % sensitivity, where the head alone cannot reach the
// screen edges (MenuCamera.FreeLook): the camera stands offset / BRM_ENC east (u) and south (v) of its spot
// BRM_BEHIND behind the eye. The server moves the camera and turns the head back by the same cursor distance in ONE
// packet (relative rotation), so the sum below does not change when it re-centres. Read relative to the eye's block
// first (whole blocks: exact in float), so the float camera position resolves it to ~1e-5 units. Exactly 0 at 100 %
// (the camera on its spot).
vec2 brm_offset() {
    vec3 d = (vec3(CameraBlockPos) - vec3(BRM_EYE_BLOCK)) - CameraOffset - (BRM_EYE - vec3(BRM_EYE_BLOCK));
    return vec2(d.x, d.z - BRM_BEHIND) * BRM_ENC;
}

// cursor point on the menu plane from the view rotation: the camera's forward axis is minus the third row of the
// rotation (column-major mv[col][row]), its right axis the first row; yaw right / pitch up in degrees, BRM_K units
// each (as far as BRM_HEAD_TURN / BRM_HEAD_PITCH), plus the offset (brm_offset), clamped to the window
// (brm_screen). Yaw comes from the right axis (always level: the camera never rolls), so it is defined even
// looking straight up or down (the forward axis has no horizontal part there: atan(0, 0)); past the edge the cursor
// stays pinned on it (looking behind: on the side the head is turned to, until the server turns the head back,
// MenuCamera.FreeLook#steer).
vec2 brm_cursor(mat4 mv, float sens) {
    vec3 f = -vec3(mv[0][2], mv[1][2], mv[2][2]);
    vec3 r = vec3(mv[0][0], mv[1][0], mv[2][0]);
    float yaw = degrees(atan(r.z, r.x));
    float pitch = degrees(asin(clamp(f.y, -1.0, 1.0)));
    float k = BRM_K * sens;
    vec2 turn = vec2(BRM_HEAD_TURN, BRM_HEAD_PITCH) * k;
    vec2 lim = brm_screen();
    return clamp(clamp(vec2(yaw, pitch) * k, -turn, turn) + brm_offset(), -lim, lim);
}

// the fixed lens: FOV 70 vertically, narrowed so a 16:9 view still fits a taller window; depth terms and axis signs
// from the real projection (the backend may flip y)
mat4 brm_lens() {
    float aspect = abs(ProjMat[1][1] / ProjMat[0][0]);
    float fy = 1.0 / BRM_TAN;
    if (aspect < 16.0 / 9.0) fy *= aspect / (16.0 / 9.0);
    mat4 m = mat4(0.0);
    m[0][0] = sign(ProjMat[0][0]) * fy / aspect;
    m[1][1] = sign(ProjMat[1][1]) * fy;
    m[2][2] = ProjMat[2][2];
    m[2][3] = ProjMat[2][3];
    m[3][2] = ProjMat[3][2];
    return m;
}

// clip position of a camera-relative vertex: vanilla outside the free-look menu, the fixed menu view inside it
vec4 brm_position(vec3 rel, mat4 mv, int mark, float sens) {
    if (!brm_active()) {
        return ProjMat * mv * vec4(rel, 1.0);
    }
    if (mark == 2) return vec4(0.0, 0.0, -2.0, 1.0);   // the server's cursor: outside the clip volume
    vec3 p = rel + vec3(CameraBlockPos) - CameraOffset - BRM_EYE;
    if (mark == 1) {
        // the shader cursor is parked behind the eye (so it is never seen without this shader): mirror it in front,
        // then move it to the cursor point, scaled by its depth like every lifted menu element (CursorTracker#point)
        p.z = -p.z;
        p.xy += brm_cursor(mv, sens) * (-p.z / BRM_D);
    }
    return brm_lens() * vec4(p, 1.0);
}

vec4 brm_position(vec3 rel, mat4 mv, int mark) {
    return brm_position(rel, mv, mark, 1.0);
}

// item / entity vertices: the mark and the sensitivity from the lightmap coordinates
vec4 brm_position(vec3 rel, mat4 mv, ivec2 light) {
    return brm_position(rel, mv, brm_mark(light), brm_sens(light));
}

// ------------------------------------------------------------------ client-side hover highlight
// The main menu's hover highlight is drawn here, per frame from the head rotation like the cursor, so a button lights
// up the instant the cursor enters it (the server's own hover state trails the head by a tick plus the ping; it still
// decides clicks and sounds, from the very same box). Each highlight is the background of a one-space text display
// spawned on the button centre (MenuScene#highlights, HoverCode); its background colour carries the button's box:
//   alpha 16..19 = the marker (+1 accent bar, +2 danger colours); 24 / 25 = the halo (amber / danger), a faint copy
//          a little larger than the band that feathers its edges. Without this shader none of them shows: the text
//          fragment shader discards alpha < 0.1.
//   rgb (24 bits) = cx2 & 63 | (cy2 & 63) << 6 | w << 12 | h << 19: the box centre in half art px, modulo 64 (the raw
//          vertex lies within 16 art px of the centre and supplies the rest), its size in art px (w <= 127, h <= 31).
// Each corner of the small raw box is moved to the matching corner of the band (left / right, below / above by its
// side of the centre), so the fully open band is exactly the hover sprite it replaces (vi_<id>_hover, menu_art.py):
// the box inset 1 art px top and bottom, an accent bar the first 1.5 px, a fade from the left edge to 80% of the width.
// Smoothing without per-button state: the band eases open with how far the cursor is inside the box (BRM_HL_EASE art
// px, smoothstep): at the edge it shows at 45% strength, 60% of its height and a short fade, growing to the full band;
// moving down the list therefore cross-fades from one item to the next instead of switching.
// Shown (alpha) only while the cursor is inside the box. Server mirror and parity test: HoverCode, CursorSimTest.
const float BRM_PX = BRM_HALF_V / 180.0;   // one art pixel in plane units (MenuArt.P)
const float BRM_HL_EASE = 2.5;             // art px inside the box over which the band eases open (HoverCode.EASE)

// alpha < 0: not a highlight vertex (rel untouched); otherwise the vertex colour to draw with (alpha 0: hidden)
vec4 brm_highlight(inout vec3 rel, vec4 color, mat4 mv, ivec2 light) {
    int a = int(round(color.a * 255.0));
    bool halo = a == 24 || a == 25;
    if ((a < 16 || a > 19) && !halo) return vec4(-1.0);
    if (!brm_active()) return vec4(-1.0);
    ivec3 c = ivec3(round(color.rgb * 255.0));
    int code = (c.r << 16) | (c.g << 8) | c.b;
    vec3 off = vec3(CameraBlockPos) - CameraOffset - BRM_EYE;
    vec3 p = rel + off;
    if (p.z > -0.01) return vec4(-1.0);
    vec2 q = p.xy * (BRM_D / -p.z) / BRM_PX;                     // this vertex on the menu plane, art px
    ivec2 q2 = ivec2(round(q * 2.0));
    ivec2 d = (ivec2(code & 63, (code >> 6) & 63) - q2) & 63;    // centre - vertex, half px, wrapped to -32 .. 31
    d -= ivec2(greaterThanEqual(d, ivec2(32))) * 64;
    vec2 ctr = vec2(q2 + d) * 0.5;
    vec2 hs = vec2(float((code >> 12) & 127), float((code >> 19) & 31)) * 0.5;
    bool bar = !halo && (a & 1) != 0;
    bool danger = halo ? a == 25 : (a & 2) != 0;
    vec2 cur = brm_cursor(mv, brm_sens(light)) / BRM_PX;
    vec2 hin = hs - abs(cur - ctr);                                // cursor depth inside the box per axis, art px
    float ease = smoothstep(0.0, min(BRM_HL_EASE, hs.y), min(hin.x, hin.y));
    bool right = q.x >= ctr.x;
    float left = ctr.x - hs.x;
    float x = !right ? left : (bar ? left + 1.5 : left + mix(1.0, 1.6, ease) * hs.x);
    float ey = halo ? (hs.y + 0.5) * mix(0.75, 1.0, ease) : (hs.y - 1.0) * mix(0.6, 1.0, ease);
    float y = ctr.y + (q.y >= ctr.y ? 1.0 : -1.0) * ey;
    if (halo && !right) x -= 0.5;
    p.xy = vec2(x, y) * BRM_PX * (-p.z / BRM_D);
    rel = p - off;
    if (any(greaterThan(abs(cur - ctr), hs))) return vec4(0.0);  // CursorTracker#inside: |d| <= half size
    float k = mix(0.45, 1.0, ease);
    if (bar) return vec4((danger ? vec3(255.0, 138.0, 128.0) : vec3(232.0, 211.0, 106.0)) / 255.0, k);
    vec3 base = danger ? vec3(150.0, 40.0, 30.0) : vec3(150.0, 112.0, 36.0);
    return vec4(base / 255.0, right ? 0.0 : (halo ? 44.0 : 120.0) / 255.0 * k);
}

#endif
