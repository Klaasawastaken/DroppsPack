#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:brmenu_look.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void main() {
    // brmenu: main-menu hover highlight (26.3 draws text display backgrounds with this shader; brmenu_look.glsl)
    vec3 brmPos = Position;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    vec4 brmHl = brm_highlight(brmPos, Color, ModelViewMat, UV2);
#elif !defined(IS_GUI)
    // see-through text has no lightmap input: no sensitivity mark, reads as 1.0x
    vec4 brmHl = brm_highlight(brmPos, Color, ModelViewMat, ivec2(0, 0));
#else
    vec4 brmHl = vec4(-1.0);
#endif
    // brmenu: world text goes through the free-look menu view (brmenu_look.glsl, MenuCamera.FreeLook); vanilla in the GUI
    gl_Position = brm_position(brmPos, ModelViewMat, 0);

#if defined(IS_GUI)
    // brmenu: BackroomsMenu camcorder OSD corner groups (marker colour, see build_camhud.py) -> the screen corners
    ivec3 brmC = ivec3(round(Color.rgb * 255.0));
    int brmTier = (brmC.r & 7) - 1;
    int brmSide = (brmC.b & 7) - 3;
    if ((brmC.g & 7) == 5 && brmSide >= 0 && brmSide <= 1 && brmTier >= 0 && brmTier <= 2) {
        mat4 brmM = ProjMat * ModelViewMat;
        float brmGw = 2.0 / abs(brmM[0][0]);
        float brmGh = 2.0 / abs(brmM[1][1]);
        bool brmBottom = Position.y > brmGh - 32.0;
        if (Position.y < 40.0 || brmBottom) {
            float brmHw = brmTier == 0 ? 226.0 : (brmTier == 1 ? 300.0 : 452.0);
            float brmDx = brmHw + 4.0 - 0.5 * brmGw;
            if (brmSide == 1) brmDx = -brmDx;
            float brmDy = (brmBottom && brmGw < 404.0) ? -10.0 : 0.0;
            gl_Position.x += brmDx * brmM[0][0] * gl_Position.w;
            gl_Position.y += brmDy * brmM[1][1] * gl_Position.w;
        }
    }
    // brmenu: effects overlay edge layers (breffects:overlay, marker colour, see build_camhud.py) -> the whole screen
    if ((brmC.r & 7) == 6 && (brmC.g & 7) == 7 && (brmC.b & 7) == 2) {
        vec2 brmN = gl_Position.xy / gl_Position.w;
        vec2 brmD = abs(brmN) * vec2(1.0 / abs(ProjMat[0][0]), 1.0 / abs(ProjMat[1][1]));
        bool brmHit = false;
        if (abs(brmD.x - 256.0) < 2.0 && abs(brmD.y - 144.0) < 16.0) brmHit = true;
        if (abs(brmD.x - 320.0) < 2.0 && abs(brmD.y - 180.0) < 16.0) brmHit = true;
        if (abs(brmD.x - 480.0) < 2.0 && abs(brmD.y - 270.0) < 16.0) brmHit = true;
        if (brmHit) gl_Position.xy = sign(brmN) * gl_Position.w;
    }
    // brmenu: hollow VHS pairs (brdeath:vhs, FX_SCALE_MARK, see build_camhud.py): 1024 x 576 design -> the real GUI
    if ((brmC.r & 7) == 6 && (brmC.g & 7) == 7 && (brmC.b & 7) == 4) {
        vec2 brmSn = gl_Position.xy / gl_Position.w;
        gl_Position.xy = brmSn * (vec2(1.0 / abs(ProjMat[0][0]), 1.0 / abs(ProjMat[1][1])) / vec2(512.0, 288.0))
            * gl_Position.w;
    }
    // brmenu: intro film layers (brintro:film, marker G & 15 == 11, kind B & 7; see build_camhud.py FILM_*)
    float brmFilmA = -1.0;
    if ((brmC.g & 15) == 11) {
        int brmK = brmC.b & 7;
        mat4 brmL = ProjMat * ModelViewMat;
        float brmLw = 2.0 / abs(brmL[0][0]);
        float brmLh = 2.0 / abs(brmL[1][1]);
        float brmBar = clamp(0.5 - 0.5 * (brmLw / brmLh) / 2.39, 0.07, 0.2);
        bool brmAb = Position.y > brmLh - 96.0 && Position.y < brmLh - 40.0;
        if (brmK == 3 && brmAb) {
            gl_Position.y += (68.0 - 0.5 * brmBar * brmLh) * brmL[1][1] * gl_Position.w;
        } else if (brmK == 5 && brmAb) {
            gl_Position.y += (0.5 * brmBar * brmLh - brmLh + 68.0) * brmL[1][1] * gl_Position.w;
            brmFilmA = float(brmC.r & 31) / 31.0;
        } else if ((brmK == 1 || brmK == 2 || brmK == 4) && Position.y < 0.34 * brmLh
                   && abs(Position.x - 0.5 * brmLw) < 16.0) {
            float brmUp = -sign(brmL[1][1]);
            bool brmHi = mod(Position.y + 1.0, 19.0) < 8.0;
            float brmX = Position.x < 0.5 * brmLw ? -1.0 : 1.0;
            float brmY = brmHi ? 1.0 : -1.0;
            if (brmK != 4) {
                int brmLv = (brmC.r & 31) | ((brmC.b >> 3) << 5);
                float brmH = brmLv <= 512 ? brmBar * float(brmLv) / 512.0
                    : mix(brmBar, 0.5, float(brmLv - 512) / 511.0);
                float brmTilt = tan(radians(0.5 * float((brmC.g >> 4) - 8))) * (brmLw / brmLh) * brmX;
                if (brmK == 1) brmY = brmHi ? 1.0 : 1.0 - 2.0 * brmH + brmTilt;
                else brmY = brmHi ? -1.0 + 2.0 * brmH + brmTilt : -1.0;
            }
            gl_Position.xy = vec2(brmX, brmY * brmUp) * gl_Position.w;
            brmFilmA = (brmK == 4 && (brmC.r & 31) > 0) ? 2.0 + float(brmC.r & 31) / 31.0 : 3.0;
        }
    }
#endif
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    // brmenu: animated glyphs (rank word-marks, Lunar moon): only the frame of the current game tick shows
    ivec3 brmA = ivec3(round(Color.rgb * 255.0));
    if ((brmA.g & 7) == 6 && (brmA.b & 7) <= 1) {
        int brmF = (brmA.r & 7) | ((brmA.b & 7) << 3);
        int brmNow = int(floor(GameTime * 8000.0)) % 12;
        if (brmF < 12 && brmF != brmNow) vertexColor.a = 0.0;
    }
#if defined(IS_GUI)
    if (brmFilmA > 1.5) vertexColor = vec4(0.0, 0.0, 0.0, brmFilmA - 2.0);   // brmenu: intro film bars / layers (alpha)
    else if (brmFilmA >= 0.0) vertexColor.a *= brmFilmA;          // brmenu: intro skip hint fade
#endif
    if (brmHl.a >= 0.0) vertexColor = brmHl;   // brmenu: hover highlight colour
    texCoord0 = UV0;
}
