#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) in vec4 brmFx;
#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

// brmenu: grade fx (build_grade_fx.py): the ring, stepped (palette colours only)
vec3 brm_ring(float h) {
    const vec3 BRM_RING[8] = vec3[8](vec3(0.9176, 0.1961, 0.2353), vec3(0.9294, 0.4627, 0.0784), vec3(1.0000, 0.7843, 0.1451), vec3(0.6000, 0.9020, 0.3725), vec3(0.0471, 0.9451, 1.0000), vec3(0.0000, 0.5961, 0.8627), vec3(0.8588, 0.2471, 0.9922), vec3(0.7843, 0.3137, 0.5255));
    return BRM_RING[int(floor(fract(h) * 8.0)) & 7];
}

// brmenu: grade fx: the colour of a tagged fragment (x = 1 text, 2 its shadow), or the colour as it was
vec4 brm_grade_fx(vec4 color, vec4 texColor, vec4 tint) {
    if (brmFx.x < 0.5) return color;
    vec3 rb = brm_ring((gl_FragCoord.x + 0.5 * gl_FragCoord.y) / (24.0 * 8.0) - brmFx.w);
    if (brmFx.x > 1.5) return vec4(rb * 0.45, texColor.a * tint.a * 0.85);              // the shadow: a rainbow shade
    if (texColor.a >= 0.04) return vec4(rb, tint.a);                                   // the letter (fx glyphs too)
    // an empty texel: the glow, when a grade fx glyph pixel (alpha about 20 / 255) is near: soft, by the distance
    // from this fragment to the nearest letter texel (in texels), out to FX_PAD
    vec2 tsz = vec2(textureSize(Sampler0, 0));
    vec2 p = texCoord0 * tsz;
    vec2 cell0 = floor(p);
    float g = 0.0;
    for (int dy = -3; dy <= 3; dy++) {
        for (int dx = -3; dx <= 3; dx++) {
            vec2 cell = cell0 + vec2(float(dx), float(dy));
            float s = texture(Sampler0, (cell + 0.5) / tsz).a;
            if (s >= 0.04 && s < 0.2) g = max(g, 1.0 - length(p - clamp(p, cell, cell + 1.0)) / 3.0);
        }
    }
    g = g * g;
    return vec4(mix(rb, vec3(1.0), 0.25), tint.a * 0.8 * g);
}
vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;
    color = brm_grade_fx(color, texColor, vertexColor * ColorModulator);   // brmenu: grade fx (build_grade_fx.py)

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
