#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:chunksection.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:brmenu_look.glsl>
// brwater> water waves (pack-water layer)
#moj_import <minecraft:brwater.glsl>
// <brwater

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
// brwater> the block atlas (to tell water apart) and the fragment position for the surface look
uniform sampler2D Sampler0;
out vec3 brwPos;
// <brwater

void main() {
    vec3 pos = Position + (ChunkPosition - CameraBlockPos) + CameraOffset;
    // brwater> small waves on the open surface of still water; 0 for every other vertex (pack-water layer)
    pos.y += brw_wave(Position, ChunkPosition, UV0, Sampler0, TextureSize);
    brwPos = pos;
    // <brwater
    gl_Position = brm_position(pos, ModelViewMat, 0);   // brmenu: free-look menu view

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}
