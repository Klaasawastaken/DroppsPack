// Backrooms water (pack-water layer, build_pack.py PACK_WATER): small waves on still water and a quiet surface look.
// Used by core/terrain.vsh and core/terrain.fsh only. Same file in the o88 (26.2) and o97 (26.3) overlays.
//
// What counts as water: a texel of the block atlas that carries the pack's own mark (build_water.py):
//   alpha exactly BRW_MARK_STILL or BRW_MARK_FLOW (vanilla water is 180), red == green, blue == red + 4.
// The water textures of this layer are the only textures of the block atlas with that mark (pack_water_check.py
// proves it for the pack and the vanilla jar; the atlas is plain 8 bit RGBA, so the values arrive exactly). No mark, no effect: with vanilla water textures every function here returns
// the vanilla value, so glass, ice, slime, honey and all other terrain are never touched.
//
// Needs from the including shader: Globals (GameTime, CameraBlockPos, CameraOffset), Fog (FogColor, fragment only).
// Define BRW_FRAGMENT before the include in the fragment shader.
#ifndef BRWATER_GLSL
#define BRWATER_GLSL

const float BRW_MARK_STILL = 178.0;   // build_water.MARK_STILL
const float BRW_MARK_FLOW = 176.0;    // build_water.MARK_FLOW
const float BRW_TAU = 6.2831853;

// 0 = not water, 1 = still water, 2 = flowing water (and the overlay seen through glass)
int brw_kind(vec4 texel) {
    vec3 c = texel.rgb * 255.0;
    if (abs(c.r - c.g) > 0.5) return 0;
    float d = c.b - c.r;
    if (d < 3.5 || d > 4.5) return 0;
    float a = texel.a * 255.0;
    if (abs(a - BRW_MARK_STILL) < 0.6) return 1;
    if (abs(a - BRW_MARK_FLOW) < 0.6) return 2;
    return 0;
}

// the atlas texel under a texel coordinate (mip 0, no filtering)
int brw_kind_at(sampler2D atlas, ivec2 size, vec2 texel) {
    ivec2 p = clamp(ivec2(floor(texel)), ivec2(0), size - ivec2(1));
    return brw_kind(texelFetch(atlas, p, 0));
}

#ifndef BRW_FRAGMENT
// ------------------------------------------------------------------ vertex: waves
// The open surface of still water is the only terrain geometry at this height inside its block: the fluid renderer
// puts it at 8/9 minus 0.001 (FluidRenderer.MAX_FLUID_HEIGHT, the 0.001 it takes off when the top face is drawn).
// Block models never have a corner there (pack_water_check.py). Flowing water, water below water, the pool
// floor and every wall keep their place, so the surface cannot come away from the blocks around it.
const float BRW_SURFACE = 0.8878889;
const float BRW_SURFACE_TOL = 0.00008;
// three slow swells, 0.030 block high at most (half a texel); the surface stays between 0.858 and 0.918
const float BRW_A1 = 0.014;
const float BRW_A2 = 0.010;
const float BRW_A3 = 0.006;

// a vertex sits on a sprite corner or edge: look at the four texels around it
bool brw_water_vertex(sampler2D atlas, ivec2 size, vec2 uv) {
    vec2 t = uv * vec2(size);
    return brw_kind_at(atlas, size, t + vec2(0.5, 0.5)) != 0
        || brw_kind_at(atlas, size, t + vec2(-0.5, 0.5)) != 0
        || brw_kind_at(atlas, size, t + vec2(0.5, -0.5)) != 0
        || brw_kind_at(atlas, size, t + vec2(-0.5, -0.5)) != 0;
}

// height offset of a terrain vertex: 0 for everything but the open surface of still water. It depends only on
// where the vertex is in the world and on the time, so faces that share a corner move together (no cracks). The
// wave vectors are whole numbers of turns over 64 blocks and the speeds whole turns per day: nothing ever jumps.
float brw_wave(vec3 position, ivec3 chunk, vec2 uv, sampler2D atlas, ivec2 size) {
    if (abs(fract(position.y) - BRW_SURFACE) > BRW_SURFACE_TOL) return 0.0;
    if (!brw_water_vertex(atlas, size, uv)) return 0.0;
    vec2 w = position.xz + vec2(chunk.xz & 63);
    float k = BRW_TAU / 64.0;
    float t = GameTime * BRW_TAU;
    return BRW_A1 * sin(k * (4.0 * w.x + 3.0 * w.y) + 150.0 * t)       // 12.8 blocks long, 8 s
         + BRW_A2 * sin(k * (-3.0 * w.x + 8.0 * w.y) + 220.0 * t)      // 7.5 blocks, 5.5 s
         + BRW_A3 * sin(k * (9.0 * w.x - 7.0 * w.y) - 330.0 * t);      // 5.6 blocks, 3.6 s
}

#else
// ------------------------------------------------------------------ fragment: surface look
// the texel this fragment draws; two taps a hair apart so a fragment on the very edge of a sprite still finds it
int brw_kind_frag(sampler2D atlas, ivec2 size, vec2 uv) {
    vec2 t = uv * vec2(size);
    int k = brw_kind_at(atlas, size, t - vec2(0.02));
    return k != 0 ? k : brw_kind_at(atlas, size, t + vec2(0.02));
}

// color: texture * vertex colour, as vanilla has it. light: the vertex colour (tint * light). pos: the fragment
// relative to the camera, dpx / dpy its screen derivatives (taken outside any branch).
// Nothing here adds light: the glint multiplies what is there, the reflection is the fog colour scaled by the
// local light, and fog is applied afterwards as always. The alpha depends on the view only, so the transparency
// passes of 26.3 (which run this with a different vertex colour) agree with the colour pass.
vec4 brw_shade(vec4 color, vec3 light, int kind, vec3 pos, vec3 dpx, vec3 dpy) {
    vec3 n = cross(dpx, dpy);
    float up = smoothstep(0.6, 0.9, abs(n.y) / max(length(n), 1.0e-9));   // 1 on the surface, 0 on side faces
    float dist = max(length(pos), 0.001);
    float graze = 1.0 - abs(pos.y) / dist;                               // 0 looking straight down, 1 along it
    float fres = graze * graze * graze * up;

    // ripple shimmer in whole texels (16 per block), periodic over 64 blocks, a few seconds per turn
    vec3 w = pos + vec3(CameraBlockPos & 63) - CameraOffset;
    vec2 q = (floor(w.xz * 16.0) + 0.5) / 16.0;
    if (up < 0.5) q = (floor(vec2(w.x + w.z, w.y) * 16.0) + 0.5) / 16.0;  // side faces: along the wall and down
    float k = BRW_TAU / 64.0;
    float t = GameTime * BRW_TAU;
    float fast = kind == 2 ? 2.0 : 1.0;                                   // flowing water is livelier
    float r1 = sin(k * (29.0 * q.x + 13.0 * q.y) + 180.0 * fast * t);     // 2 blocks long, 6.7 s (3.3 s flowing)
    float r2 = sin(k * (-11.0 * q.x + 31.0 * q.y) - 240.0 * fast * t);    // 1.9 blocks, 5 s (2.5 s flowing)
    float glint = smoothstep(0.35, 0.95, r1 * r2);                        // thin bright crests where both meet
    float strength = (kind == 2 ? 0.16 : 0.07) + 0.15 * fres;

    vec3 rgb = color.rgb * (1.0 + strength * glint);
    // at a shallow angle the surface mirrors the room: the fog colour, never brighter than the light on the water
    vec3 mirror = FogColor.rgb * max(light.r, max(light.g, light.b));
    rgb = mix(rgb, mirror, 0.55 * fres);
    // deep and far water closes up: more opaque at a shallow angle and with distance (no depth is known here)
    float a = color.a;
    a = mix(a, max(a, 0.94), 0.8 * fres);
    a = mix(a, max(a, 0.88), 0.35 * up * smoothstep(4.0, 24.0, dist));
    return vec4(rgb, a);
}
#endif

#endif
